import { Swiper, SwiperSlide } from "swiper/react";
import FeelingSlide from "./coomponents/FeelingSlide";
import { Box, Center, Spinner, useToast } from "@chakra-ui/react";
import { useEffect, useState } from "react";
import "swiper/css";
import SleepSlide from "./coomponents/SleepSlide";
import FoodSlide from "./coomponents/FoodSlide";
import ExerciseSlide from "./coomponents/ExerciseSlide";
import ThankYouSlide from "./coomponents/ThankYouSlide";
import StressSlide from "./coomponents/StressSlide";
import { urls } from "config";
import { getAxiosInstance } from "network/axiosInstance";

export interface FeelingForm {
  feeling: number;
}
export interface StressForm {
  stress: number;
}
export interface SleepForm {
  sleep: number;
}
export interface FoodForm {
  ateHealthy: string;
  unHealthyFood: string;
}
export interface WorkoutForm {
  workedOut: string;
  time: number;
  type: string;
  notes: string;
}

export interface SurveyBody {
  feeling: Number;
  stress: Number;
  sleep: Number;
  ateHealthy: string;
  unHealthyFood: string;
  workout: string;
  workoutTime: Number;
  workoutType: string;
  notes: string;
}

export const feelingInit: FeelingForm = {
  feeling: 1,
};

export const stressInit: StressForm = {
  stress: 1,
};

export const sleepInit: SleepForm = {
  sleep: 8,
};

export const foodInit: FoodForm = {
  ateHealthy: "Yes",
  unHealthyFood: "None",
};

export const workoutInit: WorkoutForm = {
  workedOut: "No",
  time: 0,
  type: "None",
  notes: "None",
};

export default function Survey() {
  const [swiper, setSwiper] = useState<any>();
  const [feeling, setFeeling] = useState<FeelingForm>(feelingInit);
  const [stress, setStress] = useState<StressForm>(stressInit);
  const [sleeping, setSleeping] = useState<SleepForm>(sleepInit);
  const [food, setFood] = useState<FoodForm>(foodInit);
  const [workout, setWorkout] = useState<WorkoutForm>(workoutInit);
  const [loading, setLoading] = useState<boolean>(false);
  const [surveyStatus, setSurveyStatus] = useState<boolean>(false);
  const [surveyBody, setSurveyBody] = useState({});

  const updateFeeling = (feeling: FeelingForm) => setFeeling(feeling);
  const updateStress = (stress: StressForm) => setStress(stress);
  const updateSleeping = (sleeping: SleepForm) => setSleeping(sleeping);
  const updateFood = (food: FoodForm) => setFood(food);
  const updateWorkout = (workout: WorkoutForm) => {
    console.log(workout);
    setWorkout(workout);
    surveySubmitClicked(workout);
    // setSurveyBody({
    //   feeling: feeling.feeling,
    //   stress: stress.stress,
    //   sleep: sleeping.sleep,
    //   ateHealthy: food.ateHealthy,
    //   unHealthyFood: food.unHealthyFood,
    //   workout: workout.workedOut,
    //   workoutTime: workout.time,
    //   workoutType: workout.type,
    //   notes: workout.notes,
    // });
  };

  const toast = useToast();

  useEffect(() => {
    setLoading(true);
    const axiosInstance = getAxiosInstance();
    axiosInstance
      .get(urls.surveyStatus)
      .then((response) => {
        if (response.status === 200) {
          const submitted = response.data.data.submitted[0];
          setSurveyStatus(submitted);
        } else {
          toast({
            title: "Something went wrong",
            status: "error",
            isClosable: true,
            position: "top",
          });
        }
        setLoading(false);
      })
      .catch((error) => {
        toast({
          title: "Something went wrong",
          status: "error",
          isClosable: true,
          position: "top",
        });
        console.log(error.response);
        setLoading(false);
      });
  }, []);

  const surveySubmitClicked = (work: WorkoutForm) => {
    const surveyBody: SurveyBody = {
      feeling: feeling.feeling,
      stress: stress.stress,
      sleep: sleeping.sleep,
      ateHealthy: food.ateHealthy,
      unHealthyFood: food.unHealthyFood,
      workout: work.workedOut,
      workoutTime: work.time,
      workoutType: work.type,
      notes: work.notes,
    };
    setLoading(true);
    const axiosInstance = getAxiosInstance();
    axiosInstance
      .post(urls.surveyPost, surveyBody)
      .then((response) => {
        if (response.status === 200) {
          setSurveyStatus(true);
        } else {
          toast({
            title: "Something went wrong",
            status: "error",
            isClosable: true,
            position: "top",
          });
        }
        setLoading(false);
      })
      .catch((error) => {
        toast({
          title: "Something went wrong 2",
          status: "error",
          isClosable: true,
          position: "top",
        });
        console.log(error.response);
        setLoading(false);
      });
  };

  return (
    <>
      {loading ? (
        <Center mt={"45vh"}>
          <Spinner
            thickness="4px"
            speed="0.65s"
            emptyColor="gray.200"
            color="blue.500"
            size="xl"
          />
        </Center>
      ) : surveyStatus && !loading ? (
        <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
          <ThankYouSlide></ThankYouSlide>
        </Box>
      ) : (
        <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
          <form>
            <Swiper
              className="mySwiper"
              onInit={(swiper) => setSwiper(swiper)}
              draggable={false}
            >
              <SwiperSlide>
                <FeelingSlide
                  swiper={swiper}
                  feeling={updateFeeling}
                ></FeelingSlide>
              </SwiperSlide>
              <SwiperSlide>
                <StressSlide
                  swiper={swiper}
                  stress={updateStress}
                ></StressSlide>
              </SwiperSlide>
              <SwiperSlide>
                <SleepSlide swiper={swiper} sleep={updateSleeping}></SleepSlide>
              </SwiperSlide>
              <SwiperSlide>
                <FoodSlide swiper={swiper} food={updateFood}></FoodSlide>
              </SwiperSlide>
              <SwiperSlide>
                <ExerciseSlide
                  swiper={swiper}
                  workout={updateWorkout}
                ></ExerciseSlide>
              </SwiperSlide>
              <SwiperSlide>
                <ThankYouSlide></ThankYouSlide>
              </SwiperSlide>
            </Swiper>
          </form>
        </Box>
      )}
    </>
  );
}
