import base64
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization

def base64url_encode(data):
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('utf-8')

# Generate an elliptic curve key pair
private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())

# Get the public key
public_key = private_key.public_key()

# Serialize the keys in PEM format
private_pem = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption()
)
public_pem = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)

# Convert keys to base64url without padding
vapid_private_key = base64url_encode(private_pem)
vapid_public_key = base64url_encode(public_pem)

# Print the keys
print("VAPID Private Key:\n", vapid_private_key)
print("VAPID Public Key:\n", vapid_public_key)
