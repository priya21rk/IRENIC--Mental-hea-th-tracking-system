// Chakra imports
import { Box, Flex, Text, useColorModeValue, useToast } from "@chakra-ui/react";
// Custom components
import Card from "components/card/Card";
import PieChart from "components/charts/PieChart";
import { VSeparator } from "components/separator/Separator";
import { urls } from "config";
import { getAxiosInstance } from "network/axiosInstance";
import { useEffect, useState } from "react";
import ReactApexChart from "react-apexcharts";

export default function WorkoutTypeGraph(props: { [x: string]: any }) {
  const [count, setCounts] = useState<Array<number>>([]);
  const [labels, setLabels] = useState<Array<string>>([]);
  const [loading, setLoading] = useState(false);

  const { ...rest } = props;
  const textColor = useColorModeValue("secondaryGray.900", "white");
  const cardColor = useColorModeValue("white", "navy.700");
  const cardShadow = useColorModeValue(
    "0px 18px 40px rgba(112, 144, 176, 0.12)",
    "unset"
  );
  const toast = useToast();

  useEffect(() => {
    const axiosInstance = getAxiosInstance();
    axiosInstance
      .get(`${urls.pieChart}?type=workOutType`)
      .then((response) => {
        if (response.status !== 200) {
          toast({
            title: "Something went wrong",
            status: "error",
            isClosable: true,
            position: "top",
          });
        }
        console.log("Ate healthy", response.data.data);
        setCounts(response.data.data.counts);
        setLabels(response.data.data.labels);
        setLoading(false);
      })
      .catch((error) => {
        toast({
          title: "Something went wrong",
          status: "error",
          isClosable: true,
          position: "top",
        });
        console.log(error.response);
        setLoading(false);
      });
  }, []);

  return (
    <Card
      p="20px"
      alignItems="center"
      flexDirection="column"
      w="100%"
      {...rest}
    >
      <Flex
        px={{ base: "0px", "2xl": "10px" }}
        justifyContent="space-between"
        alignItems="center"
        w="100%"
        mb="8px"
      >
        <Text
          me="auto"
          color={textColor}
          fontSize="xl"
          fontWeight="700"
          lineHeight="100%"
        >
          Workout Type Chart
        </Text>
      </Flex>

      <ReactApexChart
        options={{
          labels: [...labels],
          colors: ["#4318FF", "#6AD2FF", "#748499"],
          chart: {
            width: "50px",
          },
          states: {
            hover: {
              filter: {
                type: "none",
              },
            },
          },
          legend: {
            show: false,
          },
          dataLabels: {
            enabled: false,
          },
          fill: {
            colors: ["#4318FF", "#6AD2FF", "#748499"],
          },
          tooltip: {
            enabled: true,
            theme: "dark",
          },
        }}
        series={count}
        type="pie"
        width="100%"
        height="100%"
      />
      <Card
        bg={cardColor}
        flexDirection="row"
        boxShadow={cardShadow}
        w="100%"
        p="15px"
        px="20px"
        mt="15px"
        mx="auto"
      >
        {/* <Flex direction="column" py="5px">
          <Flex align="center">
            <Box h="8px" w="8px" bg="brand.500" borderRadius="50%" me="4px" />
            <Text
              fontSize="xs"
              color="secondaryGray.600"
              fontWeight="700"
              mb="5px"
            >
              Yes
            </Text>
          </Flex>
          <Text fontSize="lg" color={textColor} fontWeight="700">
            {count[0]}
          </Text>
        </Flex>
        <VSeparator mx={{ base: "60px", xl: "60px", "2xl": "60px" }} />
        <Flex direction="column" py="5px" me="10px">
          <Flex align="center">
            <Box h="8px" w="8px" bg="#6AD2FF" borderRadius="50%" me="4px" />
            <Text
              fontSize="xs"
              color="secondaryGray.600"
              fontWeight="700"
              mb="5px"
            >
              {count[1]}
            </Text>
          </Flex>
          <Text fontSize="lg" color={textColor} fontWeight="700">
            25%
          </Text>
        </Flex>
        <VSeparator mx={{ base: "60px", xl: "60px", "2xl": "60px" }} />
        <Flex direction="column" py="5px" me="10px">
          <Flex align="center">
            <Box h="8px" w="8px" bg="#EFF4FB" borderRadius="50%" me="4px" />
            <Text
              fontSize="xs"
              color="secondaryGray.600"
              fontWeight="700"
              mb="5px"
            >
              Somewhat
            </Text>
          </Flex>
          <Text fontSize="lg" color={textColor} fontWeight="700">
            12 %
          </Text>
        </Flex> */}
      </Card>
    </Card>
  );
}
