import {
  Box,
  Button,
  Slider,
  SliderFilledTrack,
  SliderMark,
  SliderThumb,
  SliderTrack,
  Text,
  useColorModeValue,
} from "@chakra-ui/react";
import { useState } from "react";
import { Player } from "@lottiefiles/react-lottie-player";
import Card from "components/card/Card";

import stressLottie from "assets/lottie/stressLottie.json";
import { StressForm, stressInit } from "..";

export default function StressSlide(props: {
  swiper: any;
  stress: (value: StressForm) => void;
}) {
  const [sliderValue, setSliderValue] = useState(stressInit.stress);
  const labelStyles = {
    mt: "2",
    ml: "-2.5",
    fontSize: "sm",
  };

  const textColor = useColorModeValue("navy.700", "white");

  const nextButtonClicked = () => {
    props.stress({ stress: sliderValue });
    props.swiper.slideNext();
  };

  return (
    <Card alignItems={"center"}>
      <Text
        mt={50}
        color={textColor}
        fontSize="30px"
        fontWeight="700"
        lineHeight="100%"
      >
        How would you like to rate your stress level today?
      </Text>
      <Player
        autoplay
        loop
        src={stressLottie}
        style={{ height: "300px", width: "300px" }}
      />
      <Slider
        aria-label="slider-ex-6"
        value={sliderValue}
        onChange={(val) => setSliderValue(val)}
        min={1}
        max={5}
        step={1}
      >
        <SliderMark value={1} {...labelStyles}>
          1
        </SliderMark>
        <SliderMark value={3} {...labelStyles}>
          3
        </SliderMark>
        <SliderMark value={5} {...labelStyles}>
          5
        </SliderMark>
        <SliderMark
          value={sliderValue}
          textAlign="center"
          bg="blue.500"
          color="white"
          mt="-10"
          ml="-5"
          w="12"
        >
          {sliderValue}
        </SliderMark>
        <SliderTrack>
          <SliderFilledTrack />
        </SliderTrack>
        <SliderThumb />
      </Slider>
      <Box mt={50}>
        <Button
          variant="darkBrand"
          color="white"
          fontSize="sm"
          fontWeight="500"
          borderRadius="70px"
          px="24px"
          py="5px"
          onClick={nextButtonClicked}
        >
          Next
        </Button>
      </Box>
    </Card>
  );
}
