import db_init as db
from flask import Flask, request, jsonify, make_response, session
from dotenv import load_dotenv
import os
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import utils
from flask_bcrypt import Bcrypt
from datetime import timedelta, datetime
from werkzeug.exceptions import abort
import psycopg2
from Models import ResponseModel, SurveyModel
from Schemas import UserSchema, LoginSchema
import marshmallow as marshmallow
import openai
from pywebpush import webpush, WebPushException
import json
import schedule
import time
from flask import Flask, render_template
from flask_cors import CORS

load_dotenv()
app = Flask(__name__)
cors = CORS(app)
app.config['JWT_SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=30)
app.config['CORS_HEADERS'] = 'Content-Type'
jwt = JWTManager(app)
bcrypt = Bcrypt(app)

#Initailize the database
@app.cli.command('initdb')
def initialize_db():
    db.initialize()

@app.route('/')
def home():
    return render_template('push-notification.html') 


db_conn = utils.db_conn()


@app.route('/register', methods=['POST'])
def register():
    schema = UserSchema()
    try:
        data = schema.load(request.json)
    except marshmallow.ValidationError as e:
        return jsonify(ResponseModel(status_code=400,message=e.messages).to_dict()), 400
    password = data.get('password')
    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    if utils.check_user_exists(data.get('email'))is not None:
        return jsonify(ResponseModel(status_code=400,message='Email id already registered').to_dict()), 400
    try:
        cur = db_conn.cursor()
        query = "INSERT INTO users (email, password, full_name, dob) VALUES (%s, %s, %s,%s);"
        cur.execute(query, (data.get('email'), hashed_password, data.get('fullName'), data.get('dob'))) 
        cur.close()
        result =  ResponseModel(message= 'User Registred Successfully', status_code=200)
        return jsonify(result.to_dict()) 
    except RuntimeError as e:
        return jsonify(ResponseModel(status_code=400,message=e.messages).to_dict()), 500

# @app.before_request
# def filter_requests():  
#     if '/secure' in request.path:
#         if not request.headers.get('Authorization'):
#             return jsonify(ResponseModel(status_code=401,message="Un Authorized").to_dict()), 401  # Unauthorized

@app.route('/login', methods=['POST'])
def login():
    schema = LoginSchema()
    try:
        data = schema.load(request.json)
    except marshmallow.ValidationError as e:
        return jsonify(ResponseModel(status_code=400,message=e.messages).to_dict()), 400
    try:
        email = data.get('email')
        password = data.get('password')
        if utils.check_user_exists(email)is None:
            return jsonify({'error':'Email Id is not registered.'}), 400
        stored_password = utils.get_password_by_email(email)
        if not bcrypt.check_password_hash(stored_password, password):
            return jsonify({'error':'Invalid Password.'}), 400
        user_id = utils.get_userid_by_email(email)
        access_token = create_access_token(identity=user_id)
        return jsonify(ResponseModel(status_code=200,message="Logged in Successfully", data= {'token':access_token}).to_dict()), 200
    except (RuntimeError, marshmallow.ValidationError) as e:
        return jsonify(ResponseModel(status_code=400,message=e.messages).to_dict()), 500


@app.route('/secure/survey', methods=['POST'])
@jwt_required()
def log_data():
    user_id = get_jwt_identity()
    data = request.get_json()    
    try:
        cur = db_conn.cursor()
        query = """
            INSERT INTO survey 
            (user_id, input_date, stress, feeling, sleep, ate_healthy, unhealthy_food, 
            workout, workout_time, workout_type, notes)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cur.execute(query,(user_id, datetime.now().date(), data['stress'], data['feeling'], data['sleep'], data['ateHealthy'], data['unHealthyFood'], data['workout'], data['workoutTime'], data['workoutType'], data['notes']))
        cur.close()
        db_conn.commit()
        return jsonify(ResponseModel(status_code=200,message='Survey Submitted Successfully.').to_dict()), 200   
    except (RuntimeError, psycopg2.Error)as e:
        return jsonify(ResponseModel(status_code=500,message='Failed to submit survey.').to_dict()), 500   
    
@app.route('/secure/user', methods=['GET'])
@jwt_required()
def getUserDetails():
    try:
        user_id = get_jwt_identity()
        cur = db_conn.cursor()
        query = """ select * from users where id = %s"""
        cur.execute(query, (user_id,))
        data = cur.fetchone()
        cur.close()
        user_details = {
            'name': data[2],
            'email': data[1],
            'dob': str(data[3])  
        }   
        return jsonify(ResponseModel(status_code=200,message='User fetched successfully', data= user_details).to_dict()), 200   
    except RuntimeError:
         return jsonify(ResponseModel(status_code=500,message='Failed to fetch user').to_dict()), 500   
    

@app.route('/secure/survey', methods=['GET'])
@jwt_required()
def getSurvey():
    try:
        user_id = get_jwt_identity()
        cur = db_conn.cursor()
        query =  """ select * from survey where user_id = %s""" 
        cur.execute(query, (user_id,))
        data = cur.fetchall()
        survey_list = [{
            'date': str(row[1]), 'stress' : row[3], 'feeling' : row[4], 'sleep' : row[5], 
            'ateHealthy' : row[6], 'unHealthy' : row[7], 'workOut' : row[8], 'workOutTime' : row[9],
            'workOutType' : row[10], 'notes' : row[11]
        } for row in data]
        return jsonify(ResponseModel(status_code=200,message='Survey fetched successfully', data= survey_list).to_dict()), 200   
    except RuntimeError:
        return jsonify(ResponseModel(status_code=500,message='Failed to fetch survey').to_dict()), 500   
    
@app.route('/secure/line-graph', methods=['GET'])
@jwt_required()
def getGraph():
    try:
        graph_type = request.args.get('type')
        column_mappings = {
            'sleep': 'sleep',
            'stress': 'stress',
            'feeling': 'feeling',
            'workOutTime': 'workout_time'
        }

        if graph_type in column_mappings:
            column_name = column_mappings[graph_type]
        else:
            return "Invalid graph type"

        user_id = get_jwt_identity()
        conn = utils.db_conn()
        cur = conn.cursor()
        data_query =  """ select {} from survey 
                        where user_id = %s 
                        and input_date >= (current_date - interval '7 day') 
                        order by input_date""".format(column_name)
        cur.execute(data_query, (user_id,))
        data_list = [row[0] for row in cur.fetchall()] 
        date_query =  """ select input_date from survey 
                        where user_id = %s 
                        and input_date >= (current_date - interval '7 day') 
                        order by input_date""" 
        cur.execute(date_query, (user_id,))
        date_list = [row[0] for row in cur.fetchall()] 
        return jsonify(ResponseModel(status_code=200,message='Graph fetched successfully', data= {'x' : date_list, 'y' : data_list}).to_dict()), 200 
    except:
        return jsonify(ResponseModel(status_code=500,message='Failed to fetch graph').to_dict()), 500   

@app.route('/secure/survey-status', methods=['GET'])
@jwt_required()
def getSurveyStatus():
    try:
        user_id = get_jwt_identity()
        conn = utils.db_conn()
        cur = conn.cursor()
        query = ''' SELECT COALESCE((SELECT DISTINCT true FROM survey WHERE input_date = current_date AND user_id = %s), false);'''
        cur.execute(query, (user_id,))
        data = cur.fetchone()
        return jsonify(ResponseModel(status_code=200,message='status fetched successfully', data= {'submitted' : data}).to_dict()), 200   
    except:
        return jsonify(ResponseModel(status_code=500,message='Failed to fetch status').to_dict()), 500   

@app.route('/secure/pi-chart', methods=['GET'])
@jwt_required()
def getPiGraph():
    try:
        graph_type = request.args.get('type')
        column_mappings = {
            'ateHealthy': 'ate_healthy',
            'workOut': 'workout',
            'workOutType': 'workout_type'
        }

        if graph_type in column_mappings:
            column_name = column_mappings[graph_type]
        else:
            return "Invalid graph type"
        user_id = get_jwt_identity()
        cur = db_conn.cursor()
        query = '''SELECT DISTINCT {}, COUNT(*) AS count
                    FROM survey
                    where user_id = %s and input_date >= (current_date - interval '7 day')
                    GROUP BY {};'''.format(column_name, column_name)
        cur.execute(query,(user_id,))
        data = cur.fetchall()
        labels = [row[0] for row in data]
        counts = [row[1] for row in data]
        response_data = {
            'labels' : labels,
            'counts' : counts
        }
        return jsonify(ResponseModel(status_code=200,message='Graph fetched successfully', data= response_data).to_dict()), 200 
    except:
        return jsonify(ResponseModel(status_code=500,message='Failed to fetch graph').to_dict()), 500   


@app.route('/secure/ai-assistant', methods=['GET'])
@jwt_required()
def ai_assistant():
    try:
        openai.api_key = os.getenv('OPEN_API_KEY')
        messages = []
        while input != "quit()":
            message = request.args.get('prompt')
            messages.append({"role": "user", "content": message})
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=messages)
            reply = response["choices"][0]["message"]["content"]
            return jsonify(ResponseModel(status_code=200,message='Prompt success', data= {'response' : reply}).to_dict()), 200 
    except:
        return jsonify(ResponseModel(status_code=500,message='Propmt failed').to_dict()), 500   


# @app.route('/subscribe', methods=['POST'])
# def subscribe():
#     # user_id = get_jwt_identity()
#     subscription = request.json.get('subscription')
#     cur = db_conn.cursor()
#     # query = "INSERT INTO subscriptions (end_point, keys) VALUES (%s, %s,%s);"
#     # cur.execute(query, (subscription['endpoint']), subscription['keys'],user_id)
#     query = "INSERT INTO subscriptions (data) VALUES (%s);"
#     cur.execute(query, (json.dumps(subscription),))
#     cur.close()
#     db_conn.commit()
#     return jsonify({'message': 'Subscription added successfully'})

# @app.route('/send_notification', methods=['POST'])
# def send_notification():
#     with app.app_context():
#         # user_id = get_jwt_identity()
#         vapid_private_key= os.getenv('VAPID')
#         payload = {
#             "notification": {
#                 "title": "Scheduled Notification",
#                 "body": "Please complete your daily survey",
#                 "icon": "static/notification.png", 
#                 "badge": "static/notification.png"
#             }
#         }

#         cur = db_conn.cursor()
#         # query = "select end_point, keys from subscriptions where user_id = %s"
#         # cur.execute(query,(user_id,))
#         query = "select data from subscriptions"
#         cur.execute(query)
#         data = cur.fetchall()
#         for subscription_tuple in data:
#             subscription = subscription_tuple[0] 
#             try:
#                 webpush(subscription_info=subscription, data=json.dumps(payload), vapid_private_key=vapid_private_key, vapid_claims={"sub": "mailto: <abcd@gmail.com>"})
#             except WebPushException as ex:
#                 print("Error sending notification:", str(ex))

#         return jsonify({'message': 'Notifications sent successfully'})  

# schedule.every(1).minutes.do(send_notification)

def run_scheduler():
    while True:
        schedule.run_pending()
        time.sleep(1)


if __name__ == '__main__':
 import threading
 scheduler_thread = threading.Thread(target=run_scheduler)
 scheduler_thread.start()
 app.run(debug=True)