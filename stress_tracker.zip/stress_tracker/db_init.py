import utils

def initialize():
    conn = utils.db_conn()
    cur = conn.cursor()
    cur.execute('''CREATE TABLE if not exists public.users (
	id bigserial NOT NULL,
	email varchar(255) NULL,
	full_name varchar(255) NULL,
	dob date,
	"password" varchar(255) NULL,
	deleted bool NOT NULL DEFAULT false,
	updated_on timestamp NULL,
	created_on timestamp NULL,
	CONSTRAINT users_email_uk UNIQUE (email),
	CONSTRAINT tb_users_pkey PRIMARY KEY (id)
);
CREATE TABLE if not exists public.survey (
	id bigserial NOT NULL,
	input_date timestamp,
	user_id bigserial,
	stress int,
	feeling int,
	sleep FLOAT8,
	ate_healthy varchar,
	unhealthy_food varchar,
	workout varchar,
	workout_time int,
	workout_type varchar,
	notes varchar,
	deleted bool NOT NULL DEFAULT false,
	updated_on timestamp NULL,
	created_on timestamp NULL,
	CONSTRAINT tb_survey_pkey PRIMARY KEY (id),
	constraint fk_user_id foreign key (user_id) references public.users(id)	);
''')
    conn.commit()
    cur.close()
    conn.close()
