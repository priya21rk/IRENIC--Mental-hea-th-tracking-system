import {
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Box,
  useToast,
} from "@chakra-ui/react";
import { useEffect } from "react";
import SleepChart from "../default/components/SleepChart";
import StressChart from "../default/components/StressChart";
import AteHealthyGraph from "./components/AteHealthyGraph";
import FeelingGraph from "./components/FeelingGraph";
import TimeWorkedOutGraph from "./components/TimeWorkedOutGraph";
import WorkedOutGraph from "./components/WorkedOutGraph";
import WorkoutTypeGraph from "./components/WorkoutType";

export default function Graphs() {
  const toast = useToast();
  useEffect(() => {}, []);

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <Tabs>
        <TabList>
          <Tab>Feeling</Tab>
          <Tab>Stress</Tab>
          <Tab>Sleep</Tab>
          <Tab>Ate Healthy</Tab>
          <Tab>Worked Out</Tab>
          <Tab>Time Worked Out</Tab>
          <Tab>Workout Type</Tab>
        </TabList>

        <TabPanels>
          <TabPanel>
            <FeelingGraph />
          </TabPanel>
          <TabPanel>
            <StressChart />
          </TabPanel>
          <TabPanel>
            <SleepChart />
          </TabPanel>
          <TabPanel>
            <AteHealthyGraph />
          </TabPanel>
          <TabPanel>
            <WorkedOutGraph />
          </TabPanel>
          <TabPanel>
            <TimeWorkedOutGraph />
          </TabPanel>
          <TabPanel>
            <WorkoutTypeGraph />
          </TabPanel>
        </TabPanels>
      </Tabs>
    </Box>
  );
}
