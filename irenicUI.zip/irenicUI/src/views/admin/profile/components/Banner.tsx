// Chakra imports
import { Avatar, Box, Flex, Text, useColorModeValue } from "@chakra-ui/react";
import Card from "components/card/Card";

export default function Banner(props: {
  banner: string;
  name: string;
  email: string;
  age: string;
}) {
  const { banner, name, email, age, ...rest } = props;
  const textColorPrimary = useColorModeValue("secondaryGray.900", "white");
  return (
    <Card mb={{ base: "0px", lg: "20px" }} alignItems="center" {...rest}>
      <Box
        bg={`url(${banner})`}
        bgSize="cover"
        borderRadius="16px"
        h="131px"
        w="100%"
      />
      <Text color={textColorPrimary} fontWeight="bold" fontSize="xl" mt="10px">
        {name}
      </Text>
      <Text
        color={textColorPrimary}
        fontWeight="medium"
        fontSize="large"
        mt="10px"
      >
        {email}
      </Text>
      <Text
        color={textColorPrimary}
        fontWeight="normal"
        fontSize="16px"
        mt="10px"
      >
        Age: {age}
      </Text>
    </Card>
  );
}
