import {
  Box,
  Button,
  Input,
  Stack,
  Text,
  useColorModeValue,
} from "@chakra-ui/react";
import { useState } from "react";
import { Radio, RadioGroup } from "@chakra-ui/react";
import { Player } from "@lottiefiles/react-lottie-player";
import Card from "components/card/Card";

import FoodLottie from "assets/lottie/foodLottie.json";
import { FoodForm, foodInit } from "..";

export default function FoodSlide(props: {
  swiper: any;
  food: (value: FoodForm) => void;
}) {
  const textColor = useColorModeValue("navy.700", "white");
  const [ateHealthy, setAteHealthy] = useState(foodInit.ateHealthy);
  const [isJunkFood, setIsJunkFood] = useState(false);
  const [junkFood, setJunkFood] = useState(foodInit.unHealthyFood);

  const radioButtonChanged = (value: string) => {
    if (value === "No" || value === "Somewhat") {
      setIsJunkFood(true);
    } else {
      setIsJunkFood(false);
    }
    setAteHealthy(value);
  };

  const handleJunkFoodChange = (event: any) => setJunkFood(event.target.value);

  const nextButtonClicked = () => {
    props.food({
      ateHealthy: ateHealthy,
      unHealthyFood: junkFood,
    });
    props.swiper.slideNext();
  };

  return (
    <Card alignItems={"center"}>
      <Text
        mt={50}
        color={textColor}
        fontSize="30px"
        fontWeight="700"
        lineHeight="100%"
      >
        Did you eat healthy today?
      </Text>
      <Box mt={30}>
        <Player
          autoplay
          loop
          src={FoodLottie}
          style={{ height: "300px", width: "300px" }}
        ></Player>
      </Box>
      <Box mt={30}>
        <RadioGroup onChange={radioButtonChanged} value={ateHealthy}>
          <Stack direction="column">
            <Radio value="Yes">Yes</Radio>
            <Radio value="No">No</Radio>
            <Radio value="Somewhat">Somewhat</Radio>
          </Stack>
        </RadioGroup>
      </Box>
      {isJunkFood ? (
        <Box mt={30}>
          <Text
            color={textColor}
            fontSize="18px"
            fontWeight="700"
            lineHeight="100%"
          >
            Track Unhealthy Food Here
          </Text>
          <Input
            mt={5}
            placeholder="Pizza, Ice Cream etc..`"
            value={junkFood}
            onChange={handleJunkFoodChange}
          />
        </Box>
      ) : (
        <></>
      )}
      <Box mt={50}>
        <Button
          variant="darkBrand"
          color="white"
          fontSize="sm"
          fontWeight="500"
          borderRadius="70px"
          px="24px"
          py="5px"
          onClick={nextButtonClicked}
        >
          Next
        </Button>
      </Box>
    </Card>
  );
}
