import {
  Box,
  Button,
  Center,
  Grid,
  Heading,
  SimpleGrid,
  Stack,
  Image,
  Text,
  useToast,
} from "@chakra-ui/react";
import Card from "components/card/Card";
import chatUI from "assets/img/ui/chat.svg";
import "@chatscope/chat-ui-kit-styles/dist/default/styles.min.css";
import {
  MainContainer,
  ChatContainer,
  MessageList,
  Message,
  MessageInput,
  MessageModel,
} from "@chatscope/chat-ui-kit-react";
import { useEffect, useState } from "react";
import { getAxiosInstance } from "network/axiosInstance";
import { urls } from "config";

const chatInit: MessageModel[] = [
  {
    direction: "incoming",
    position: 0,
    message:
      "Hello, Welcome to IRENIC AI Assistant. Talk to me about your feelings. I am here to listen!",
    sentTime: String(0),
    sender: "IRENIC",
    type: "text",
  },
];

export default function AIAssistant() {
  const [messages, setMessages] = useState<MessageModel[]>(chatInit);
  const [waitingServer, setWaitingServer] = useState<boolean>(false);

  const toast = useToast();

  const handleMessageSend = (msg: string) => {
    setMessages((prevMessages) => [
      ...prevMessages,
      {
        direction: "outgoing",
        position: 0,
        message: msg,
        sentTime: new Date().toLocaleTimeString(),
        sender: "User",
        type: "html",
      },
    ]);
    // setWaitingServer(true);

    const chatPrompt = encodeURIComponent(msg.trim());
    const axiosInstance = getAxiosInstance();
    axiosInstance
      .get(`${urls.AIAssistant}?prompt=${chatPrompt}`)
      .then((response) => {
        if (response.status === 200) {
          const aiResponse = response.data.data.response;
          console.log(aiResponse);
          setMessages((prevMessages) => [
            ...prevMessages,
            {
              direction: "incoming",
              position: 0,
              message: aiResponse,
              sentTime: new Date().toLocaleTimeString(),
              sender: "User",
              type: "html",
            },
          ]);
          setWaitingServer(false);
        } else {
          toast({
            title: "Something went wrong",
            status: "error",
            isClosable: true,
            position: "top",
          });
        }
      })
      .catch((error) => {
        toast({
          title: "Something went wrong",
          status: "error",
          isClosable: true,
          position: "top",
        });
        console.log(error.response);
      });
  };

  // useEffect(() => {
  //   setTimeout(() => console.log([...messages, "Super mone"]), 500);
  // }, [messages]);

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <Card padding={"150px"}>
        <div style={{ position: "relative", height: "500px" }}>
          <MainContainer>
            <ChatContainer>
              <MessageList>
                {messages.map((msg) => {
                  return (
                    <Message
                      type="text"
                      model={msg}
                      key={msg.sentTime}
                    ></Message>
                  );
                })}
              </MessageList>
              <MessageInput
                placeholder="Type message here"
                onSend={handleMessageSend}
                disabled={waitingServer}
                attachButton={false}
              />
            </ChatContainer>
          </MainContainer>
        </div>
      </Card>
    </Box>
  );
}
