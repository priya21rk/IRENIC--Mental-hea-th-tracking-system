import { Text, useColorModeValue } from "@chakra-ui/react";
import Card from "components/card/Card";
import ThankYouLottie from "assets/lottie/thankYouLottie.json";
import { Player } from "@lottiefiles/react-lottie-player";

export default function ThankYouSlide(props: {}) {
  const textColor = useColorModeValue("navy.700", "white");

  return (
    <Card alignItems={"center"}>
      <Player
        autoplay
        loop
        src={ThankYouLottie}
        style={{ height: "300px", width: "300px" }}
      />
      <Text
        mt={50}
        color={textColor}
        fontSize="30px"
        fontWeight="700"
        lineHeight="100%"
      >
        Thank you for completing the daily survey.
      </Text>
    </Card>
  );
}
