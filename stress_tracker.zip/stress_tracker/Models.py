
class ResponseModel(object):
    statusCode = 200
    message = None
    data = None

    def __init__(self, status_code=None, data=None, message=None):
        if status_code is not None:
            self.status_code = status_code
        if data is not None:
            self.data = data
        if message is not None:
            self.message = message

    def to_dict(self):
        return {
            "status_code": self.status_code,
            "data": self.data,
            "message": self.message,
        } 

class SurveyModel(object):
    def __init__(self, userId, inputDate, stress, feeling, sleep, ateHealthy,
                 unHealthyFood, workout, workoutTime, workoutType, notes):
        self.userId = userId
        self.inputDate = inputDate
        self.stress = stress
        self.feeling = feeling
        self.sleep = sleep
        self.ateHealthy = ateHealthy
        self.unHealthyFood = unHealthyFood
        self.workout = workout
        self.workoutTime = workoutTime
        self.workoutType = workoutType
        self.notes = notes
        
    def to_dict(self):
        return {
            "userId":self.userId,
            "inputDate":self.inputDate,
            "stress": self.stress,
            "feeling": self.feeling,
            "sleep": self.sleep,
            "ate_healthy": self.ate_healthy,
            "unhealthy_food": self.unhealthy_food,
            "workout": self.workout,
            "workout_time": self.workout_time,
            "workout_type": self.workout_type,
            "notes": self.notes,
        }    


