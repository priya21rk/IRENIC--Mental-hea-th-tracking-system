export const config = {
    baseUrl : 'http://127.0.0.1:5000'
}

export const urls = {
    login: `/login`,
    register: `/register`,
    surveyStatus: '/secure/survey-status',
    surveyPost: '/secure/survey',
    surveyGet: '/secure/survey',
    lineGraph: '/secure/line-graph',
    pieChart: '/secure/pi-chart',
    AIAssistant: "secure/ai-assistant",
    Profile: "/secure/user"
}

const firebaseConfig = {
    apiKey: "AIzaSyCh8Q8CXyq3tPUFkvGG7dS3WHs5vtj257M",
    authDomain: "irenic-39c54.firebaseapp.com",
    projectId: "irenic-39c54",
    storageBucket: "irenic-39c54.appspot.com",
    messagingSenderId: "225062825761",
    appId: "1:225062825761:web:ad06f0d876bfd61a10d860",
    measurementId: "G-KJYGCGL7Q2"
  };
  