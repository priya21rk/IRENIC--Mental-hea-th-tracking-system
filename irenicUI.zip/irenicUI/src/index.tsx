import React from "react";
import ReactDOM from "react-dom";
import "./assets/css/App.css";
import { HashRouter, Route, Switch, Redirect } from "react-router-dom";
import AdminLayout from "./layouts/admin";
import { ChakraProvider } from "@chakra-ui/react";
import theme from "./theme/theme";
import SignIn from "views/auth/signIn";
import Register from "views/auth/register";

const isAuth = () => {
  const token = localStorage.getItem("token");
  if (token) return true;
  return false;
};

const PrivateRoute = ({ children, ...rest }: any) => {
  return (
    <Route
      {...rest}
      render={() => {
        return isAuth() === true ? children : <Redirect to={"/auth/sign-in"} />;
      }}
    ></Route>
  );
};

ReactDOM.render(
  <ChakraProvider theme={theme}>
    <React.StrictMode>
      <HashRouter>
        <Switch>
          <PrivateRoute path={"/admin"}>
            <Route path={`/admin`} component={AdminLayout} />
          </PrivateRoute>
          <Route path={`/auth/sign-in`} component={SignIn} />
          <Route path={`/auth/register`} component={Register} />
          <Redirect from="/" to="/admin" />
        </Switch>
      </HashRouter>
    </React.StrictMode>
  </ChakraProvider>,
  document.getElementById("root")
);
