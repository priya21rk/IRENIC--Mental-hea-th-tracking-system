import {
  Box,
  Button,
  Center,
  Grid,
  Heading,
  SimpleGrid,
  Stack,
  Image,
  Text,
} from "@chakra-ui/react";
import Card from "components/card/Card";

import Video1 from "assets/img/resource/video_1.jpg";
import Video2 from "assets/img/resource/video_2.jpg";
import Video3 from "assets/img/resource/video_3.jpg";
import Video4 from "assets/img/resource/video_4.jpg";
import Video5 from "assets/img/resource/video_5.jpg";

export default function Resources() {
  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <SimpleGrid
        mb="20px"
        columns={{ sm: 1, md: 2 }}
        spacing={{ base: "20px", xl: "20px" }}
      ></SimpleGrid>
      <Grid
        mb="20px"
        gridTemplateColumns={{
          md: "repeat(2, 1fr)",
          xl: "repeat(3, 1fr)",
          "2xl": "repeat(5, 1fr)",
        }}
        gap={{ base: "20px", xl: "20px" }}
      >
        <Card maxW="sm">
          <Box>
            <Image
              src={Video1}
              alt="Green double couch with wooden legs"
              borderRadius="lg"
            />
            <Stack mt="6" spacing="3">
              <Heading size="md">
                WHEN YOU FEEL LIKE QUITTING - Best Inspiring Speech on Mental
                Health.
              </Heading>
              <Text>
                When You Feel Like Quitting - Inspiring Speech on Depression &
                Mental Health.
              </Text>
            </Stack>
          </Box>
          <Center mt="5">
            <Button variant="ghost" colorScheme="blue">
              Visit Resource
            </Button>
          </Center>
        </Card>

        <Card maxW="sm">
          <Box>
            <Image
              src={Video2}
              alt="Green double couch with wooden legs"
              borderRadius="lg"
            />
            <Stack mt="6" spacing="3">
              <Heading size="md">WATCH WHEN YOU FEEL LIKE GIVING UP!</Heading>
              <Text>Best of Jordan Peterson Greatest Advice.</Text>
            </Stack>
          </Box>
          <Center mt="5">
            <Button variant="ghost" colorScheme="blue">
              Visit Resource
            </Button>
          </Center>
        </Card>

        <Card maxW="sm">
          <Box>
            <Image
              src={Video3}
              alt="Green double couch with wooden legs"
              borderRadius="lg"
            />
            <Stack mt="6" spacing="3">
              <Heading size="md">
                Daily Habits to Reduce Stress and Anxiety.
              </Heading>
              <Text>
                In this video, I teach 10 essential daily habits to manage
                stress and anxiety.
              </Text>
            </Stack>
          </Box>
          <Center mt="5">
            <Button variant="ghost" colorScheme="blue">
              Visit Resource
            </Button>
          </Center>
        </Card>

        <Card maxW="sm">
          <Box>
            <Image
              src={Video4}
              alt="Green double couch with wooden legs"
              borderRadius="lg"
            />
            <Stack mt="6" spacing="3">
              <Heading size="md">
                6 Therapy Skills to Stop Overthinking Everything.
              </Heading>
              <Text>
                Learn more in one of my in-depth mental health courses:
                https://courses.therapyinanutshell.com.
              </Text>
            </Stack>
          </Box>
          <Center mt="5">
            <Button variant="ghost" colorScheme="blue">
              Visit Resource
            </Button>
          </Center>
        </Card>

        <Card maxW="sm">
          <Box>
            <Image
              src={Video5}
              alt="Green double couch with wooden legs"
              borderRadius="lg"
            />
            <Stack mt="6" spacing="3">
              <Heading size="md">
                How to stop your thoughts from controlling your life.
              </Heading>
              <Text>
                Albert Hobohm shares life-altering, personal and professional
                ideas on how to take charge of your reality.
              </Text>
            </Stack>
          </Box>
          <Center mt="5">
            <Button variant="ghost" colorScheme="blue">
              Visit Resource
            </Button>
          </Center>
        </Card>
      </Grid>
    </Box>
  );
}
