import {
  Box,
  Button,
  Slider,
  SliderFilledTrack,
  SliderMark,
  SliderThumb,
  SliderTrack,
  Text,
  useColorModeValue,
} from "@chakra-ui/react";
import { useState } from "react";
import { Player } from "@lottiefiles/react-lottie-player";
import Card from "components/card/Card";

import sleepLottie from "assets/lottie/sleep.json";
import { SleepForm, sleepInit } from "..";

export default function SleepSlide(props: {
  swiper: any;
  sleep: (value: SleepForm) => void;
}) {
  const [sliderValue, setSliderValue] = useState(sleepInit.sleep);
  const labelStyles = {
    mt: "2",
    ml: "-2.5",
    fontSize: "sm",
  };

  const textColor = useColorModeValue("navy.700", "white");

  const nextButtonClicked = () => {
    props.sleep({ sleep: sliderValue });
    props.swiper.slideNext();
  };

  return (
    <Card alignItems={"center"}>
      <Text
        mt={50}
        color={textColor}
        fontSize="30px"
        fontWeight="700"
        lineHeight="100%"
      >
        How much sleep did you get?
      </Text>
      <Player
        autoplay
        loop
        src={sleepLottie}
        style={{ height: "300px", width: "300px" }}
      />
      <Slider
        aria-label="slider-ex-6"
        value={sliderValue}
        onChange={(val) => setSliderValue(val)}
        min={0}
        max={12}
        step={0.5}
      >
        <SliderMark value={2} {...labelStyles}>
          2Hrs
        </SliderMark>
        <SliderMark value={4} {...labelStyles}>
          4Hrs
        </SliderMark>
        <SliderMark value={6} {...labelStyles}>
          6Hrs
        </SliderMark>
        <SliderMark value={8} {...labelStyles}>
          8Hrs
        </SliderMark>
        <SliderMark value={10} {...labelStyles}>
          10Hrs
        </SliderMark>
        <SliderMark
          value={sliderValue}
          textAlign="center"
          bg="blue.500"
          color="white"
          mt="-10"
          ml="-5"
          w="12"
        >
          {sliderValue}Hrs
        </SliderMark>
        <SliderTrack>
          <SliderFilledTrack />
        </SliderTrack>
        <SliderThumb />
      </Slider>
      <Box mt={50}>
        <Button
          variant="darkBrand"
          color="white"
          fontSize="sm"
          fontWeight="500"
          borderRadius="70px"
          px="24px"
          py="5px"
          onClick={nextButtonClicked}
        >
          Next
        </Button>
      </Box>
    </Card>
  );
}
