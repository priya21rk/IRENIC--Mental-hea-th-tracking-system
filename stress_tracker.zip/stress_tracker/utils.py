import psycopg2
from dotenv import load_dotenv
import os
from psycopg2 import sql


load_dotenv()

def db_conn():
    conn = psycopg2.connect(database=os.getenv('DB_NAME'), host="localhost", user=os.getenv('DB_USER'), password=os.getenv('DB_PW'), port=5432)
    return conn


def check_user_exists(email):
    conn  = db_conn()
    cursor  =conn.cursor()
    exists = sql.SQL("select true from users where email = %s")
    cursor.execute(exists, (email, ))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result

def get_password_by_email(email):
    conn  = db_conn()
    cursor  =conn.cursor()
    get_password_by_user_name = sql.SQL("select password from users where email = %s")
    cursor.execute(get_password_by_user_name, (email, ))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result[0]

def get_userid_by_email(email):
    conn  = db_conn()
    cursor  =conn.cursor()
    get_password_by_user_name = sql.SQL("select id from users where email = %s")
    cursor.execute(get_password_by_user_name, (email, ))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result[0]
           