self.addEventListener('install', event => {
  console.log('Service Worker: Installed');
});

self.addEventListener('activate', event => {
  console.log('Service Worker: Activated');
});

self.addEventListener('push', event => {
  const options = {
    body: event.data.text(),
    icon: 'static/notification.png',
    badge: 'static/notification.png'  
  };

  event.waitUntil(
    self.registration.showNotification('Push Notification', options)
  );
});

