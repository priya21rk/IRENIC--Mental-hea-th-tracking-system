import {
  Box,
  Spinner,
  Text,
  useColorModeValue,
  useToast,
} from "@chakra-ui/react";
import Card from "components/card/Card";
import { urls } from "config";
import { format } from "date-fns";
import { getAxiosInstance } from "network/axiosInstance";
import { useEffect, useState } from "react";
import ReactApexChart from "react-apexcharts";

export default function SleepChart() {
  const textColor = useColorModeValue("secondaryGray.900", "white");
  const [x, setX] = useState([]);
  const [y, setY] = useState([]);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    const axiosInstance = getAxiosInstance();
    axiosInstance
      .get(`${urls.lineGraph}?type=sleep`)
      .then((response) => {
        if (response.status !== 200) {
          toast({
            title: "Something went wrong",
            status: "error",
            isClosable: true,
            position: "top",
          });
        }
        console.log(response.data.data);
        const xData: Array<string> = response.data.data.x;
        const xDates = xData.map((date) =>
          format(new Date(date), "MMMM do, yyyy")
        );
        setX(xDates);
        setY(response.data.data.y);
        setLoading(false);
      })
      .catch((error) => {
        toast({
          title: "Something went wrong",
          status: "error",
          isClosable: true,
          position: "top",
        });
        console.log(error.response);
        setLoading(false);
      });
  }, []);

  return (
    <>
      {loading ? (
        <Spinner
          thickness="4px"
          speed="0.65s"
          emptyColor="gray.200"
          color="blue.500"
          size="xl"
        />
      ) : (
        <Card
          justifyContent="center"
          alignItems="center"
          flexDirection="column"
          w="100%"
          mb="0px"
        >
          <Text
            me="auto"
            color={textColor}
            fontSize="xl"
            fontWeight="700"
            lineHeight="100%"
          >
            Sleep Chart
          </Text>
          <Box minH="260px" minW="75%" mt="auto">
            <ReactApexChart
              options={{
                chart: {
                  id: "apexchart-example",
                  dropShadow: {
                    enabled: true,
                    top: 13,
                    left: 0,
                    blur: 10,
                    opacity: 0.1,
                    color: "#4318FF",
                  },
                },
                colors: ["#4318FF", "#39B8FF"],
                stroke: {
                  curve: "smooth",
                },
                yaxis: {
                  show: true,
                  min: 0,
                  max: 12,
                },
                xaxis: {
                  categories: x,
                },
              }}
              series={[
                {
                  name: "Sleep",
                  data: y,
                },
              ]}
              type="line"
              width="100%"
              height="100%"
            />
          </Box>
        </Card>
      )}
    </>
  );
}
