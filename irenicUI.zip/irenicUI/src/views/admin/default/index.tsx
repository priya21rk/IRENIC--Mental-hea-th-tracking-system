import {
  Box,
  SimpleGrid,
  Text,
  Heading,
  Button,
  useToast,
  Center,
  Spinner,
} from "@chakra-ui/react";
import Card from "components/card/Card";
import { urls } from "config";
import { getAxiosInstance } from "network/axiosInstance";
import { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import SleepChart from "./components/SleepChart";
import StressChart from "./components/StressChart";

export default function UserReports() {
  const [loading, setLoading] = useState<boolean>(false);
  const [surveyStatus, setSurveyStatus] = useState<boolean>(false);

  const toast = useToast();
  const history = useHistory();

  const viewMoreClicked = () => {
    history.push("/admin/graphs");
  };

  useEffect(() => {
    setLoading(true);
    const axiosInstance = getAxiosInstance();
    axiosInstance
      .get(urls.surveyStatus)
      .then((response) => {
        if (response.status === 200) {
          const submitted = response.data.data.submitted[0];
          setSurveyStatus(submitted);
        } else {
          toast({
            title: "Something went wrong",
            status: "error",
            isClosable: true,
            position: "top",
          });
        }
        setLoading(false);
      })
      .catch((error) => {
        toast({
          title: "Something went wrong",
          status: "error",
          isClosable: true,
          position: "top",
        });
        console.log(error.response);
        setLoading(false);
      });
  }, []);

  return (
    <>
      {loading ? (
        <Center mt={"45vh"}>
          <Spinner
            thickness="4px"
            speed="0.65s"
            emptyColor="gray.200"
            color="blue.500"
            size="xl"
          />
        </Center>
      ) : (
        <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
          <Card mb="20px">
            <Heading size="md">Hey😊, Welome back.</Heading>
            {surveyStatus ? (
              <Text mt="10px">
                Thanks for doing the daily survey! Keep going.
              </Text>
            ) : (
              <Text mt="10px">You haven't done your daily survey today.</Text>
            )}
          </Card>

          <SimpleGrid columns={{ base: 1, md: 2, xl: 2 }} gap="20px" mb="20px">
            {/* <TotalSpent />
        <WeeklyRevenue /> */}
            <SleepChart />
            <StressChart />
          </SimpleGrid>

          <Button onClick={viewMoreClicked}>View More Stats</Button>
        </Box>
      )}
    </>
  );
}
