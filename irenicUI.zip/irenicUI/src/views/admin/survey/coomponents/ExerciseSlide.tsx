import {
  Box,
  Button,
  Slider,
  SliderFilledTrack,
  SliderMark,
  SliderThumb,
  SliderTrack,
  Stack,
  Text,
  useColorModeValue,
  Textarea,
} from "@chakra-ui/react";
import { useState } from "react";
import { Radio, RadioGroup } from "@chakra-ui/react";
import { Player } from "@lottiefiles/react-lottie-player";
import Card from "components/card/Card";

import exerciseLottie from "assets/lottie/exerciseLottie.json";
import { WorkoutForm } from "..";
import { workoutInit } from "..";

export default function ExerciseSlide(props: {
  swiper: any;
  workout: (value: WorkoutForm) => void;
}) {
  const textColor = useColorModeValue("navy.700", "white");
  const [workedOut, setWorkedOut] = useState(workoutInit.workedOut);
  const [isExercise, setIsExercise] = useState(false);
  const [time, setTime] = useState(workoutInit.time);
  const [type, setType] = useState(workoutInit.type);
  const [notes, setNotes] = useState(workoutInit.notes);

  const labelStyles = {
    mt: "2",
    ml: "-2.5",
    fontSize: "sm",
  };

  const radioButtonChanged = (value: string) => {
    if (value === "Yes") {
      setIsExercise(true);
    } else {
      setIsExercise(false);
    }
    setWorkedOut(value);
  };

  const handleNotesChange = (event: any) => {
    setNotes(event.target.value);
  };

  const submitButtonClicked = () => {
    const obj = {
      workedOut,
      time,
      type,
      notes,
    };
    props.workout({ ...obj });
    // props.submit();
  };

  return (
    <Card alignItems={"center"}>
      <Text
        mt={50}
        color={textColor}
        fontSize="30px"
        fontWeight="700"
        lineHeight="100%"
      >
        Did you exercise today?
      </Text>
      <Player
        autoplay
        loop
        src={exerciseLottie}
        style={{ height: "300px", width: "300px" }}
      ></Player>
      <RadioGroup mt={5} onChange={radioButtonChanged} value={workedOut}>
        <Stack direction="column">
          <Radio value="Yes">Yes</Radio>
          <Radio value="No">No</Radio>
        </Stack>
      </RadioGroup>
      {isExercise ? (
        <Box mt={30}>
          <Text
            color={textColor}
            fontSize="18px"
            fontWeight="700"
            lineHeight="100%"
          >
            How long was your workout? (minutes)
          </Text>
          <Slider
            mt={10}
            aria-label="slider-ex-6"
            value={time}
            onChange={(val) => setTime(val)}
            min={0}
            max={120}
            step={15}
          >
            <SliderMark value={30} {...labelStyles}>
              30min
            </SliderMark>
            <SliderMark value={60} {...labelStyles}>
              60min
            </SliderMark>
            <SliderMark value={90} {...labelStyles}>
              90min
            </SliderMark>
            <SliderMark value={90} {...labelStyles}>
              90min
            </SliderMark>
            <SliderMark
              value={time}
              textAlign="center"
              bg="blue.500"
              color="white"
              mt="-10"
              ml="-5"
              w="12"
            >
              {time}min
            </SliderMark>
            <SliderTrack>
              <SliderFilledTrack />
            </SliderTrack>
            <SliderThumb />
          </Slider>
          <Box mt={"60px"}>
            <Text
              color={textColor}
              fontSize="18px"
              fontWeight="700"
              lineHeight="100%"
            >
              What exercise(s) did you do?
            </Text>
            <Box mt={5}>
              <RadioGroup onChange={setType} value={type}>
                <Stack direction="column">
                  <Radio value="Strength">Strength</Radio>
                  <Radio value="Meditation">Meditation</Radio>
                  <Radio value="Other">Other</Radio>
                </Stack>
              </RadioGroup>
            </Box>
          </Box>
          <Box mt={"60px"}>
            <Text
              color={textColor}
              fontSize="18px"
              fontWeight="700"
              lineHeight="100%"
            >
              Care to write note for yourself?
            </Text>
            <Textarea
              mt={5}
              placeholder="Note to myself"
              onChange={handleNotesChange}
              value={notes}
            />
          </Box>
        </Box>
      ) : (
        <></>
      )}
      <Box mt={50}>
        <Button
          variant="darkBrand"
          color="white"
          fontSize="sm"
          fontWeight="500"
          borderRadius="70px"
          px="24px"
          py="5px"
          onClick={submitButtonClicked}
        >
          Submit
        </Button>
      </Box>
    </Card>
  );
}
