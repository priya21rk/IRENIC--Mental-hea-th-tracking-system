import { Icon } from "@chakra-ui/react";
import {
  MdBarChart,
  MdPerson,
  MdHome,
  MdLock,
  MdGrid3X3,
  MdAutoGraph,
  MdAssistant,
} from "react-icons/md";
import { TbCheckupList } from "react-icons/tb";

// Admin Imports
import MainDashboard from "views/admin/default";
import Profile from "views/admin/profile";

// Auth Imports
import Survey from "views/admin/survey";
import Statistics from "views/admin/statistics";
import Resources from "views/admin/resources";
import Graphs from "views/admin/graphs";
import AIAssistant from "views/admin/AIAssistant";

const routes = [
  {
    name: "Main Dashboard",
    layout: "/admin",
    path: "/default",
    icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
    component: MainDashboard,
  },
  {
    name: "Daily Survey",
    layout: "/admin",
    path: "/survey",
    icon: (
      <Icon as={TbCheckupList} width="20px" height="20px" color="inherit" />
    ),
    component: Survey,
  },
  {
    name: "Statistics",
    layout: "/admin",
    path: "/statistics",
    icon: <Icon as={MdBarChart} width="20px" height="20px" color="inherit" />,
    component: Statistics,
  },
  {
    name: "Graphs",
    layout: "/admin",
    path: "/graphs",
    icon: <Icon as={MdAutoGraph} width="20px" height="20px" color="inherit" />,
    component: Graphs,
  },
  {
    name: "Resources",
    layout: "/admin",
    path: "/resources",
    icon: <Icon as={MdGrid3X3} width="20px" height="20px" color="inherit" />,
    component: Resources,
  },
  {
    name: "AI Assistant",
    layout: "/admin",
    path: "/assistant",
    icon: <Icon as={MdLock} width="20px" height="20px" color="inherit" />,
    component: AIAssistant,
  },
  {
    name: "Profile",
    layout: "/admin",
    path: "/profile",
    icon: <Icon as={MdAssistant} width="20px" height="20px" color="inherit" />,
    component: Profile,
  },
  // {
  //   name: "NFT Marketplace",
  //   layout: "/admin",
  //   path: "/nft-marketplace",
  //   icon: (
  //     <Icon
  //       as={MdOutlineShoppingCart}
  //       width="20px"
  //       height="20px"
  //       color="inherit"
  //     />
  //   ),
  //   component: NFTMarketplace,
  //   secondary: true,
  // },
  // {
  //   name: "Data Tables",
  //   layout: "/admin",
  //   icon: <Icon as={MdBarChart} width="20px" height="20px" color="inherit" />,
  //   path: "/data-tables",
  //   component: DataTables,
  // },
  // {
  //   name: "Sign In",
  //   layout: "/auth",
  //   path: "/sign-in",
  //   icon: <Icon as={MdLock} width="20px" height="20px" color="inherit" />,
  //   component: SignIn,
  // },
  // {
  //   name: "Register",
  //   layout: "/auth",
  //   path: "/register",
  //   icon: <Icon as={MdLock} width="20px" height="20px" color="inherit" />,
  //   component: Register,
  // },
  // {
  //   name: "RTL Admin",
  //   layout: "/rtl",
  //   path: "/rtl-default",
  //   icon: <Icon as={MdHome} width="20px" height="20px" color="inherit" />,
  //   component: RTL,
  // },
];

export default routes;
