export const getLineChartOptions = (x: Array<string>): Object => {
    return {
      chart: {
        toolbar: {
          show: false,
        },
        dropShadow: {
          enabled: true,
          top: 13,
          left: 0,
          blur: 10,
          opacity: 0.1,
          color: "#4318FF",
        },
      },
      colors: ["#4318FF", "#39B8FF"],
      markers: {
        size: 0,
        colors: "white",
        strokeColors: "#7551FF",
        strokeWidth: 3,
        strokeOpacity: 0.9,
        strokeDashArray: 0,
        fillOpacity: 1,
        discrete: [],
        shape: "circle",
        radius: 2,
        offsetX: 0,
        offsetY: 0,
        showNullDataPoints: true,
      },
      tooltip: {
        theme: "dark",
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: "smooth",
        type: "line",
      },
      xaxis: {
        type: "numeric",
       categories: [
      "31/ 07 /2023",
      "01/ 08 /2023",
      "02/ 08 /2023",
      "03/ 08 /2023",
      "04/ 08 /2023",
      "05/ 08 /2023",
      "06/ 08 /2023",
    ],
        labels: {
          style: {
            colors: "#A3AED0",
            fontSize: "12px",
            fontWeight: "500",
          },
        },
        axisBorder: {
          show: false,
        },
        axisTicks: {
          show: false,
        },
      },
      yaxis: {
        show: true,
        min: 1,
        max: 5,
      },
      legend: {
        show: false,
      },
      grid: {
        show: true,
        column: {
          color: ["#7551FF", "#39B8FF"],
          opacity: 0.5,
        },
      },
      color: ["#7551FF", "#39B8FF"],
    };
  };

  export const getLineChartData = (y: Array<number>): Array<any> => {
    return [
      {
        name: "Feeling",
        data:  [1, 5, 5, 3, 1, 1, 2],
      },
    ];
  };