import axios, { AxiosInstance } from "axios";
import { config } from "config";


// export const axiosInstance = 

// export const axiosInstaceNonSecure = axios.create({baseURL: config.baseUrl});

export const getAxiosInstance = (): AxiosInstance => {
  return axios.create({
    baseURL: config.baseUrl,
    headers: {
        "Authorization" : `Bearer ${localStorage.getItem('token')}`,
        "Content-Type": "application/json"
      }
});
}