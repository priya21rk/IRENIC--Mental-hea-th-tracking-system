import { Box, Button, Stack, Text, useColorModeValue } from "@chakra-ui/react";
import { useState } from "react";
import { Radio, RadioGroup } from "@chakra-ui/react";
import { Player } from "@lottiefiles/react-lottie-player";
import Card from "components/card/Card";

import HappySad from "assets/lottie/animation_lknt803e.json";
import { FeelingForm, feelingInit } from "..";

export default function FeelingSlide(props: {
  swiper: any;
  feeling: (value: FeelingForm) => void;
}) {
  const textColor = useColorModeValue("navy.700", "white");
  const [value, setValue] = useState(feelingInit.feeling.toString());

  const nextButtonClicked = () => {
    props.feeling({ feeling: parseInt(value) });
    props.swiper.slideNext();
  };

  return (
    <Card alignItems={"center"}>
      <Text
        mt={50}
        color={textColor}
        fontSize="30px"
        fontWeight="700"
        lineHeight="100%"
      >
        How do you feel today?
      </Text>
      <Player
        autoplay
        loop
        src={HappySad}
        style={{ height: "300px", width: "300px" }}
      ></Player>
      <RadioGroup onChange={setValue} value={value}>
        <Stack direction="column">
          <Radio value="1">Very Happy</Radio>
          <Radio value="2">Happy</Radio>
          <Radio value="3">Neutral</Radio>
          <Radio value="4">Sad</Radio>
          <Radio value="5">Very Sad</Radio>
        </Stack>
      </RadioGroup>
      <Box mt={50}>
        <Button
          variant="darkBrand"
          color="white"
          fontSize="sm"
          fontWeight="500"
          borderRadius="70px"
          px="24px"
          py="5px"
          onClick={nextButtonClicked}
        >
          Next
        </Button>
      </Box>
    </Card>
  );
}
