import { Box, SimpleGrid, useToast } from "@chakra-ui/react";
// import statisticsTableData from "./components/data";
import StatisticsTable, { RowObj } from "./components/StatisticsTable";
import { useState, useEffect } from "react";
import { getAxiosInstance } from "network/axiosInstance";
import { urls } from "config";
import { format } from "date-fns";
import "assets/css/table.css";

const tableData2 = [
  {
    ateHealthy: "Yes",
    date: "2023-08-06 00:00:00",
    feeling: 1,
    notes: "None",
    sleep: 8.0,
    stress: 1,
    unHealthy: "None",
    workOut: "No",
    workOutTime: 0,
    workOutType: "None",
  },
  {
    ateHealthy: "Yes",
    date: "2023-08-06 00:00:00",
    feeling: 1,
    notes: "None",
    sleep: 8.0,
    stress: 1,
    unHealthy: "None",
    workOut: "No",
    workOutTime: 0,
    workOutType: "None",
  },
];

export default function Statistics() {
  const [loading, setLoading] = useState<boolean>(false);
  const [tableData, setTableData] = useState<RowObj[]>([]);
  const toast = useToast();
  useEffect(() => {
    const axiosInstance = getAxiosInstance();
    axiosInstance
      .get(urls.surveyPost)
      .then((response) => {
        if (response.status !== 200) {
          toast({
            title: "Something went wrong",
            status: "error",
            isClosable: true,
            position: "top",
          });
        }
        // console.log(response.data.data);
        setTableData(response.data.data);
        console.log(tableData);
        // setLoading(false);
      })
      .catch((error) => {
        toast({
          title: "Something went wrong",
          status: "error",
          isClosable: true,
          position: "top",
        });
        console.log(error.response);
        setLoading(false);
      });
  }, []);

  return (
    <>
      {loading ? (
        <h1> Loading </h1>
      ) : (
        <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
          <SimpleGrid
            mb="20px"
            columns={{ sm: 1, md: 2 }}
            spacing={{ base: "20px", xl: "20px" }}
          ></SimpleGrid>
          {/* <StatisticsTable tableData={tableData} /> */}

          <table className="table">
            <tr className="table-header">
              <th className="cell">DATE</th>
              <th className="cell">FEELING</th>
              <th className="cell">STRESS</th>
              <th className="cell">SLEEP(Hrs)</th>
              <th className="cell">ATE HEALTHY</th>
              <th className="cell">UNHEALTHY FOOD</th>
              <th className="cell">WORKED OUT</th>
              <th className="cell">TIME WORKED OUT(HRS)</th>
              <th className="cell">WORKOUT TYPE</th>
              <th className="cell">NOTES</th>
            </tr>
            {tableData.map((data: RowObj) => (
              <tr className="active">
                <td>{format(new Date(data.date), "MMMM do, yyyy")}</td>
                <td>{data.feeling}</td>
                <td>{data.stress}</td>
                <td>{data.sleep}</td>
                <td>{data.ateHealthy}</td>
                <td>{data.unHealthy}</td>
                <td>{data.workOut}</td>
                <td>{data.workOutTime}</td>
                <td>{data.workOutType}</td>
                <td>{data.notes}</td>
              </tr>
            ))}
          </table>
        </Box>
      )}
    </>
  );
}
